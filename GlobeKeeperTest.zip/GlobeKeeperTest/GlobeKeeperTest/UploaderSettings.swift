//
//  UploaderSettings.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit
import CoreServices

public let kUTTypeWord: CFString = "org.openxmlformats.wordprocessingml.document" as CFString

final class FileSettings {
    
    let allowedTypes = [kUTTypePDF, kUTTypeImage, kUTTypeText, kUTTypeWord]
    let maxSize: Int = 10
    let maxCount: Int = 10
}
