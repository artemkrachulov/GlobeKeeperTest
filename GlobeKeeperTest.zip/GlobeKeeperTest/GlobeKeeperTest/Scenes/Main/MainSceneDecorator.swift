//  
//  MainSceneDecorator.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

final class MainSceneDecorator {
    
    private weak var target: MainScene!
    
    init(target: MainScene) {
        self.target = target
    }
    
    func decorate() {
        target.view.backgroundColor = UIColor.lightGray
    }
}
