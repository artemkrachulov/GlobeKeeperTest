//  
//  MainScene.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit
import Moya
import Alamofire
import CoreServices

final class MainScene: UIViewController {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias ViewModel = MainSceneModel
    typealias Decorator = MainSceneDecorator

    // MARK: -
    // MARK: ** Properties **
    
    private var viewModel = ViewModel()
    private lazy var decorator = Decorator(target: self)

    // MARK: -
    // MARK: ** Connections **
    
    private lazy var infoView = InfoView()
    private lazy var documentPicker: UIDocumentPickerViewController = {
        
        let documentPicker = UIDocumentPickerViewController(documentTypes: viewModel.settings.allowedTypes.map({ String.init($0) }), in: .import)
        documentPicker.delegate = self
        
        if #available(iOS 11.0, *) {
            documentPicker.allowsMultipleSelection = true
        }
        
        return documentPicker
    }()
    
    // MARK: -
    // MARK: ** Life cycle **
    
    override func viewDidLoad() {
        super.viewDidLoad()

        create()
        decorate()
        setViewModel()
    }
    
    // MARK: -
    // MARK: ** Setup Methods **
    
    private func create() {
        
        view.addSubview(infoView)
        infoView.translatesAutoresizingMaskIntoConstraints = false
        
        infoView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        infoView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        infoView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        infoView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
    }
    
    private func decorate() {
        decorator.decorate()
    }
    
    private func setViewModel() {
        
        let infoViewModel = viewModel.infoViewModel
        infoViewModel.tapClosure = tapAction
        
        infoView.viewModel = infoViewModel
    }
    
    // MARK: -
    // MARK: ** Gesture actions **
  
    @objc private func tapAction() {
        present(documentPicker, animated: true)
    }
    
    private func showUploader(urls: [URL]) {
        
        // Search if uploader exist
        // or create new
        
        if let view = children.first(where: { $0 is UploadViewController }) as? UploadViewController {
            view.viewModel.documentURLs = urls
        } else {
            let viewModel = UploadViewControllerModel(documentURLs: urls)
            let view = UploadViewController(viewModel: viewModel)
            view.present(in: self)
        }
    }
}

extension MainScene: UIDocumentPickerDelegate {
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        
        // Shadow valiable
        
        var urls = urls
        
        // Validate
        
        let errors = [
            urls.validate(validationType: ValidatorType.size(viewModel.settings.maxSize)),
            urls.validate(validationType: ValidatorType.count(viewModel.settings.maxCount))
            ].compactMap({ $0?.localizedDescription })
        
        if errors.isEmpty {
            showUploader(urls: urls)
        } else {
            let alert = AlertFactory.makeValidation(errors: errors) { [weak self] in
                self?.showUploader(urls: urls)
            }
            self.present(alert, animated: true)
        }
      
    }
}
