//  
//  MainSceneModel.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation
import CoreServices

final class MainSceneModel {

    // MARK: -
    // MARK: ** Properties **
    
    let settings: FileSettings
    
    // View models
    
    let infoViewModel: InfoViewModel
    
    // MARK: -
    // MARK: ** Initialization **
    
    init(settings: FileSettings = .init()) {
        self.settings = settings
        self.infoViewModel = InfoViewModel(settings: settings)
    }
}
