//  
//  InfoView.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit
import Reusable

final class InfoView: UIView, NibOwnerLoadable {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias ViewModel = InfoViewModel
    
    // MARK: -
    // MARK: ** Properties **
    
    var viewModel: ViewModel! {
        didSet { setViewModel() }
    }
    // MARK: -
    // MARK: ** Connections **
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet var tapGesture: UITapGestureRecognizer!
    
    // MARK: -
    // MARK: ** Setup methods **
    
    init() {
        super.init(frame: CGRect.zero)
        
        self.setup()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setup() {
        loadNibContent()
        create()
    }
    
    private func create() {
        tapGesture.addTarget(self, action: #selector(tapAction))
    }
    
    private func setViewModel() {
        label.text = viewModel.labelText
    }
    
    // MARK: -
    // MARK: ** Gesture actions **
    
    @objc private func tapAction() {
        viewModel?.tapClosure?()
    }
}
