//  
//  InfoViewModel.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation

final class InfoViewModel {

    // MARK: -
    // MARK: ** Definitions **
    
    typealias Model = FileSettings
    
    // MARK: -
    // MARK: ** Properties **
    
    // Connection
    
    let labelText: String
    
    // Closures
    
    var tapClosure: (() -> Void)?
    
    // MARK: -
    // MARK: ** Initialization **
    
    init(settings: Model) {
        
        let formatString =  """
            Tap to open gallery.
            You able to upload %d files. Max file size is %d MB. Supported all image types, all text types, pdf and word.
        """
        
        self.labelText = String(format: formatString, settings.maxCount, settings.maxSize)
    }
}
