//
//  UploadState.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

enum UploadState {
    /// - value1: Amount offiles in uploading process
    /// - value2: Max count of files
    case processing(Int, Int)
    /// - value: Amount of failed files
    case comlete(Int)
}

extension UploadState: Equatable {}

extension UploadState {
    
    var headerAttributedText: NSAttributedString {
        
        let attributes: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 17, weight: .bold), .foregroundColor: UIColor.white ]
        
        let base, values, string: String
        let color: UIColor
        
        switch self {
        case .processing(let value, let max):
            
            base = "Processing uploads"
            values = String(format: " %d/%d", value, max)
            string = base + values
            color = .downy

        case .comlete(let failed):
            
            base = "Upload complte"
            if failed != 0 {
                values = String(format: " (%d failed)", failed)
            } else {
                values = ""
            }
            string = base + values
            color = .carnation
        }
        
        let attributedString = NSMutableAttributedString(string: string, attributes: attributes)
        
        if let range = string.range(of: values).map({ NSRange($0, in: string) }) {
            attributedString.addAttribute(.foregroundColor, value: color, range: range)
        }
        
        return attributedString
    }
}
