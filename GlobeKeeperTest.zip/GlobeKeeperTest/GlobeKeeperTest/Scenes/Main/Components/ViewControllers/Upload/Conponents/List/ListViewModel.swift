//  
//  ListViewModel.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation

final class ListViewModel {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias Model = ListItemViewModel
    
    // MARK: -
    // MARK: ** Properties **

    var itemViewModels: [Model] = [] {
        didSet { refresh?(itemViewModels) }
    }
    
    // Closure
    
    var refresh: (([Model]) -> Void)? {
        didSet { refresh?(itemViewModels) }
    }
    
    // MARK: -
    // MARK: ** Initialization **
    
    init(models: [Model] = []) {
        self.itemViewModels = models
    }
}
