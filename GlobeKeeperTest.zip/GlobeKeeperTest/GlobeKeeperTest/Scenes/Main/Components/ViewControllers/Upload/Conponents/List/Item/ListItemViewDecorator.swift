//  
//  ListItemViewDecorator.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

final class ListItemViewDecorator {
    
    private weak var target: ListItemView!
    
    init(target: ListItemView) {
        self.target = target
    }
    
    func decorate() {
        target.separatorView.backgroundColor = .mercury
        
        let attributedString = NSAttributedString(string: "Retry", attributes: [
            .font: UIFont.systemFont(ofSize: 17),
            .foregroundColor: UIColor.black,
            .underlineStyle: NSUnderlineStyle.single.rawValue])
        
        target.reloadButton.setAttributedTitle(attributedString, for: .normal)
    }
    
    func decorateState(_ state: UploadItemState) {
        
        let isUserInteractionEnabled: Bool
        
        switch state {
        case .ok:
            isUserInteractionEnabled = false
            
            target.barView.isHidden = true
            target.reloadButton.isHidden = true
            
        case .fail:
            isUserInteractionEnabled = false
            
            target.barView.isHidden = true
            target.reloadButton.isHidden = false
        case .uploading:
            isUserInteractionEnabled = true
            
            target.reloadButton.isHidden = true
            target.barView.isHidden = false
        }
        
        target.statusButton.setTitle(nil, for: .normal)
        target.statusButton.isUserInteractionEnabled = isUserInteractionEnabled
        target.statusButton.setImage(ImageFactory.makeImage(for: state)?.withRenderingMode(.alwaysOriginal), for: .normal)
    }
}
