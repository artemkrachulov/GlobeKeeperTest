//  
//  BarViewModel.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

final class BarViewModel {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias Model = Double
    
    // MARK: -
    // MARK: ** Properties **
    
    let progress: Value<Model>

    // MARK: -
    // MARK: ** Initialization **
    
    init(progress: Model = 0) {
        self.progress = Value(progress)
    }
}
