//
//  ListItemViewNetworking.swift
//  GlobeKeeperTest
//
//  Created by Artem on 16.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation
import Moya

final class ListItemViewNetworking {
    
    // MARK: -
    // MARK: ** Properties **
    
    private let provider: MoyaProvider<API>
    private let api: API
    
    //
    private var request: Cancellable!
    let state: Value<UploadItemState>
    
    // MARK: -
    // MARK: ** Initialization **
    
    internal init(provider: MoyaProvider<API>, api: API) {
        self.provider = provider
        self.api = api
        self.state = Value(.uploading(0))
    }
    
    // MARK: -
    // MARK: ** Actions **
    
    func startRequest() {
        
        state.value = .uploading(0)
        
        request = provider.request(api, progress: { [weak state] progress in
            state?.value = .uploading(progress.progress)
        }, completion: { [weak state] result in
            switch result {
            case let .success(moyaResponse):
                let statusCode = moyaResponse.statusCode
                
                switch statusCode {
                case 400, 500:
                    state?.value = .fail
                case 204:
                    state?.value = .ok
                default:
                    state?.value = .fail
                }
            case .failure:
                state?.value = .fail
            }
        })
    }
    
    func stopRequest() {
        request.cancel()
    }
}
