//  
//  ListItemViewModel.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation
import Moya

final class ListItemViewModel {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias Model = UploadItemState
    
    // MARK: -
    // MARK: ** Properties **
    
    // Connection
    
    let nameLabelText: String
    let iconImage: UIImage?
    
    // Request
    
    let networking: ListItemViewNetworking
    var state: Value<Model> {
        return networking.state
    }
    
    // Closures

    var stateChanged: ((UploadItemState) -> Void)?
    
    // MARK: -
    // MARK: ** Initialization **
    
    init(provider: MoyaProvider<API> = .init(), url: URL) {
        
        self.nameLabelText = url.lastPathComponent
        self.iconImage = ImageFactory.makeImageFrom(ext: url.pathExtension)
        
        self.networking = ListItemViewNetworking(provider: provider, api: .upload(url))
    }
}
