//  
//  HeaderViewModel.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation

final class HeaderViewModel {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias Model = UploadState
    
    // MARK: -
    // MARK: ** Properties **
    
    let state: Value<UploadState>
    
    // Closures
    
    var close: (() -> Void)?
    var showHide: (() -> Void)?

    // MARK: -
    // MARK: ** Initialization **
    
    init(state: Model) {
        self.state = Value(state)
    }
}
