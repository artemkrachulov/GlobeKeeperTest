//  
//  UploadViewController.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

final class UploadViewController: UIViewController {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias ViewModel = UploadViewControllerModel
    typealias Decorator = UploadViewControllerDecorator
    
    // MARK: -
    // MARK: ** Properties **
    
    var viewModel: ViewModel!
    private lazy var decorator = Decorator(target: self)
    
    // MARK: -
    // MARK: ** Connections **
    
    lazy var stackView: UIStackView = ViewsFactory.makeStackView()
    
    // MARK: -
    // MARK: ** Initialization **
    
    init(viewModel: ViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(nibName: nil, bundle: nil)
    }
    
    // MARK: -
    // MARK: ** Life cycle **
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        create()
        decorate()
        setViewModel()
    }
    
    // MARK: -
    // MARK: ** Setup methods **
    
    private func create() {
        
        self.view.alpha = 0
        self.view.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
        
        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        stackView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        stackView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        stackView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
    }
    
    private func decorate() {
        decorator.decorate()
    }
    
    private func setViewModel() {
        
        // Header
        let headerViewModel = viewModel.headerViewModel
        let headerView = HeaderView(viewModel: headerViewModel)
        headerViewModel.close = { [weak self] in
            self?.dismiss()
        }
        
        // List
        let listView = ListView(viewModel: viewModel.listViewModel)
        
        // Add to container
        [headerView, listView].forEach(stackView.addArrangedSubview)
        
        self.view.backgroundColor = .red
    }
    
    // MARK: -
    // MARK: ** Present **
    
    func present(in parent: UIViewController) {
        
        parent.addChild(self)
        
        parent.view.addSubview(view)
        view.translatesAutoresizingMaskIntoConstraints = false
        
        if #available(iOS 11.0, *) {
            view.leftAnchor.constraint(equalTo: parent.view.safeAreaLayoutGuide.leftAnchor, constant: 16).isActive = true
            view.rightAnchor.constraint(equalTo: parent.view.safeAreaLayoutGuide.rightAnchor, constant: -16).isActive = true
            view.bottomAnchor.constraint(equalTo: parent.view.safeAreaLayoutGuide.bottomAnchor, constant: -16).isActive = true
        } else {
            view.leftAnchor.constraint(equalTo: parent.view.leftAnchor, constant: 16).isActive = true
            view.rightAnchor.constraint(equalTo: parent.view.rightAnchor, constant: -16).isActive = true
            view.bottomAnchor.constraint(equalTo: parent.view.bottomAnchor, constant: -16).isActive = true
        }
        
        didMove(toParent: parent)
        
        UIView.animate(withDuration: 0.2) {
            self.view.alpha = 1.0
            self.view.transform = .identity
        }
    }
    
    func dismiss() {
        
        UIView.animate(withDuration: 0.2, animations: {
            self.view.alpha = 0
            self.view.transform = CGAffineTransform(translationX: 0, y: 20)
        }, completion: { _ in
            self.willMove(toParent: nil)
            self.view.removeFromSuperview()
            self.removeFromParent()
        })
    }
}
