//  
//  BarViewDecorator.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

final class BarViewDecorator {
    
    private weak var target: BarView!
    
    init(target: BarView) {
        self.target = target
    }
    
    func decorate() {
        target.barView.layer.cornerRadius = 3
        target.barView.clipsToBounds = true
        target.barView.backgroundColor = .mischka
        target.progressView.backgroundColor = .downy
    }
}
