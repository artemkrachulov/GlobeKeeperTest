//  
//  BarView.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit
import Reusable

final class BarView: UIView, NibOwnerLoadable {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias ViewModel = BarViewModel
    typealias Decorator = BarViewDecorator
    
    // MARK: -
    // MARK: ** Properties **
    
    let viewModel = ViewModel()
    private lazy var decorator = Decorator(target: self)
    
    // MARK: -
    // MARK: ** Connections **
    
    @IBOutlet weak var barView: UIView!
    var progressView: UIView!
    
    // MARK: -
    // MARK: ** Initialization **

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.setup()
    }
    
    // MARK: -
    // MARK: ** Setup methods **
    
    private func setup() {
        loadNibContent()
        create()
        decorate()
        setViewModel()
    }
    
    private func create() {
        progressView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: barView.frame.height))
        barView.addSubview(progressView)
    }
    
    private func decorate() {
        decorator.decorate()
    }
    
    private func setViewModel() {
        
        self.viewModel.progress.didChange = { [weak self] (_, value) in
            self?.progressDidChange(value)
        }
    }
    
    private func progressDidChange(_ progress: ViewModel.Model) {
        
        let animations = {
            let width = CGFloat(progress) * self.barView.frame.width
            self.progressView.frame.size.width = width
        }
        
        if progress == 0 {
            animations()
        } else {
            UIView.animate(withDuration: 0.2, animations: animations)
        }
        
    }
}
