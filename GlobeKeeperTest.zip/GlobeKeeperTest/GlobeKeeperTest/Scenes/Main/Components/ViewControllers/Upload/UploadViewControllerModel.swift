//  
//  UploadViewControllerModel.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit
import Moya

final class UploadViewControllerModel {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias Model = UploadState
    
    // MARK: -
    // MARK: ** Properties **
    
    // View models
    
    let headerViewModel: HeaderViewModel
    let listViewModel: ListViewModel
    
    // Networking
    
    private let provider: MoyaProvider<API>
    
    //
    var documentURLs: [URL] = [] {
        didSet {
            
            // Update Header text
            let itemCount = documentURLs.count
            self.headerViewModel.state.value = .processing(itemCount, itemCount)
            
            // Refresh list
            let models = documentURLs.map({ ListItemViewModel(provider: provider, url: $0) })
            models.forEach {
                  $0.stateChanged = { [weak self] (state) in
                      self?.stateChanged(state)
                  }
              }
            
            self.listViewModel.itemViewModels = models
        }
    }
    
    // MARK: -
    // MARK: ** Initialization **
    
    init(documentURLs: [URL]) {
        defer { self.documentURLs = documentURLs }
        
        self.provider = MoyaProvider<API>(plugins: [ NetworkLoggerPlugin(verbose: true) ])
        
        // Header
        let itemCount = documentURLs.count
        self.headerViewModel = HeaderViewModel(state: .processing(itemCount, itemCount))
        
        // List
        self.listViewModel = ListViewModel()
    }
    
    private func stateChanged(_ state: UploadItemState) {
        
        let states = listViewModel.itemViewModels.map({ $0.state.value })

        let uploadingCount = states.filter({
            if case .uploading = $0 { return true } else { return false }
        }).count

        guard uploadingCount == 0 else {
            self.headerViewModel.state.value = .processing(uploadingCount, states.count)
            return
        }

        let failedCount = states.filter({
            if case .fail = $0 { return true } else { return false }
        }).count

        self.headerViewModel.state.value = .comlete(failedCount)
    }
}
