//  
//  HeaderView.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit
import Reusable

final class HeaderView: UIView, NibOwnerLoadable {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias ViewModel = HeaderViewModel
    typealias Decorator = HeaderViewDecorator
    
    // MARK: -
    // MARK: ** Properties **
    
    private var viewModel: ViewModel! {
        didSet { setViewModel() }
    }
    private lazy var decorator = Decorator(target: self)
    
    // MARK: -
    // MARK: ** Connections **
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var showHideButton: UIButton!
    @IBOutlet weak var closeButton: UIButton!
    
    // MARK: -
    // MARK: ** Initialization **
    
    init(viewModel: ViewModel) {
        defer { self.viewModel = viewModel }
        super.init(frame: CGRect.zero)
        
        self.setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("This view supports only dependecy injection initalizer")
    }
    
    // MARK: -
    // MARK: ** Setup methods **
    
    private func setup() {
        loadNibContent()
        create()
        decorate()
    }
    
    private func create() {
        closeButton.addTarget(self, action: #selector(closeAction), for: .touchDown)
        showHideButton.addTarget(self, action: #selector(hideAction), for: .touchDown)
    }
    
    private func decorate() {
        decorator.decorate()
    }
    
    private func setViewModel() {
        viewModel.state.didChange = { [weak self] (_, state) in
            self?.stateDidChange(state)
        }
    }
    
    private func stateDidChange(_ state: UploadState) {
        titleLabel.attributedText = state.headerAttributedText
    }
    
    // MARK: -
    // MARK: ** Button actions **
    
    @objc private func hideAction() {
        viewModel.showHide?()
    }
    
    @objc private func closeAction() {
        viewModel.close?()
    }
}
