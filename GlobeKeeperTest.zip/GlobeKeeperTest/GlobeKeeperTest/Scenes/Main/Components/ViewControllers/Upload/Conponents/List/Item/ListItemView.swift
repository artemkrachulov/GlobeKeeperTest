//  
//  ListItemView.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit
import Reusable
import Moya

final class ListItemView: UIView, NibOwnerLoadable {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias ViewModel = ListItemViewModel
    typealias Decorator = ListItemViewDecorator
    
    // MARK: -
    // MARK: ** Properties **
    
    var viewModel: ViewModel! {
        didSet { setViewModel() }
    }
    private lazy var decorator = Decorator(target: self)
    
    // MARK: -
    // MARK: ** Connections **
    
    @IBOutlet weak var typeImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var barView: BarView!
    @IBOutlet weak var reloadButton: UIButton!
    @IBOutlet weak var statusButton: UIButton!
    @IBOutlet weak var separatorView: UIView!
    
    // MARK: -
    // MARK: ** Initialization **
    
    init(viewModel: ViewModel) {
        defer { self.viewModel = viewModel }
        super.init(frame: CGRect.zero)
        
        self.setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("This view supports only dependecy injection initalizer")
    }
    
    deinit {
        viewModel.networking.stopRequest()
    }
    
    // MARK: -
    // MARK: ** Setup methods **
    
    private func setup() {
        loadNibContent()
        create()
        decorate()
    }
    
    private func create() {
        reloadButton.addTarget(self, action: #selector(reloadAction), for: .touchDown)
        statusButton.addTarget(self, action: #selector(cancelAction), for: .touchDown)
    }
    
    private func decorate() {
        decorator.decorate()
    }
    
    private func setViewModel() {
        typeImageView.image = viewModel.iconImage
        nameLabel.text = viewModel.nameLabelText
        
        networking()
    }
    
    private func networking() {
        viewModel.networking.state.didChange = { [weak self] (_, state) in
            self?.stateDidChange(state)
        }
        viewModel.networking.startRequest()
    }
    
    private func stateDidChange(_ state: UploadItemState) {
        
        viewModel.stateChanged?(state)
        
        if case let .uploading(percentage) = state {
            barView.viewModel.progress.value = percentage
        }
        
        decorator.decorateState(state)
    }
    
    // MARK: -
    // MARK: ** Button actions **
    
    @objc private func reloadAction() {
        viewModel.networking.startRequest()
    }
    
    @objc private func cancelAction() {
        viewModel.networking.stopRequest()
    }
}
