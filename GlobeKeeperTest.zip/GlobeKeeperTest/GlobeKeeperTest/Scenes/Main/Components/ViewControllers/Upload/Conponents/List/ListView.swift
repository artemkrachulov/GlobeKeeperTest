//  
//  ListView.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

final class ListView: UIView {
    
    // MARK: -
    // MARK: ** Definitions **
    
    typealias ViewModel = ListViewModel
    
    // MARK: -
    // MARK: ** Properties **
    
    var viewModel: ViewModel! {
        didSet { setViewModel() }
    }
    
    // MARK: -
    // MARK: ** Connections **
    
    lazy var stackView: UIStackView = ViewsFactory.makeStackView()
    
    // MARK: -
    // MARK: ** Initialization **
    
    init(viewModel: ViewModel) {
        defer { self.viewModel = viewModel }
        super.init(frame: CGRect.zero)
        
        self.setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("This view supports only dependecy injection initalizer")
    }
    
    // MARK: -
    // MARK: ** Setup methods **
    
    private func setup() {
        create()
    }
    
    private func create() {
        addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        stackView.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        stackView.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        stackView.topAnchor.constraint(equalTo: topAnchor).isActive = true
        stackView.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
    }
    
    private func setViewModel() {
        viewModel.refresh = { [weak self] viewModels in
            self?.refresh(viewModels: viewModels)
        }
    }
    
    func refresh(viewModels: [ViewModel.Model]) {
        
        // Clear
        stackView.arrangedSubviews.forEach({ $0.removeFromSuperview() })
        
        // Add new
        viewModels.map(ListItemView.init).forEach(stackView.addArrangedSubview)
    }
}
