//  
//  UploadViewControllerDecorator.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

final class UploadViewControllerDecorator {
    
    private weak var target: UploadViewController!
    
    init(target: UploadViewController) {
        self.target = target
    }
    
    func decorate() {
        target.view.layer.cornerRadius = 10
        target.view.clipsToBounds = true
    }
}
