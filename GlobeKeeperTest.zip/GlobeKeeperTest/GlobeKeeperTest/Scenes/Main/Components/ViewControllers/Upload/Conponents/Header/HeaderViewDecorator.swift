//  
//  HeaderViewDecorator.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

final class HeaderViewDecorator {
    
    private weak var target: HeaderView!
    
    init(target: HeaderView) {
        self.target = target
    }
    
    func decorate() {
        
        target.backgroundColor = .mirage
        
        [(target.showHideButton, UIImage(named: "arrow_up")), (target.closeButton, UIImage(named: "close"))].forEach(styleButton)
    }
    
    fileprivate func styleButton(_ button: UIButton, with image: UIImage?) {
        button.setTitle(nil, for: .normal)
        button.setImage(image?.withRenderingMode(.alwaysOriginal), for: .normal)
     }
}
