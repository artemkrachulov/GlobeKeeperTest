//
//  FileCountValidator.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation

struct FileCountValidator: Validated {
    
    // MARK: -
    // MARK: ** Properties **
    
    private let max: Int
    
    // MARK: -
    // MARK: ** Initialization **
    
    init(_ max: Int) {
        self.max = max
    }
    
    // MARK: -
    // MARK: ** Validated Protocol **
    
    func validated(_ urls: [URL]) -> ([URL], ValidationError?) {
    
        let succeed = Array(urls.prefix(max))
        let failed = urls.dropFirst(max)
        
        var error: ValidationError?
        
        if !failed.isEmpty {
        
            error = ValidationError(message: String(format: "Over limit %d: %@", max, failed.map({ $0.lastPathComponent }).joined(separator: ", ")))
        }
        
        return (succeed, error)
    }
}
