//
//  FileSizeValidator.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation

struct FileSizeValidator: Validated {
    
    // MARK: -
    // MARK: ** Properties **
    
    private let size: Int
    
    // MARK: -
    // MARK: ** Initialization **
    
    init(_ size: Int) {
        self.size = size
    }
    
    // MARK: -
    // MARK: ** Validated Protocol **
    
    func validated(_ urls: [URL]) -> ([URL], ValidationError?) {

        var failed = [URL]()
        var big = [(URL, Float)]()
        var succeed = [URL]()
        
        for url in urls {
            
            guard let size = size(for: url) else {
                failed.append(url)
                continue
            }
            
            let mb = Float(size) / 1000000.0

            if mb > 10 {
                big.append((url, mb))
                continue
            }
            
            succeed.append(url)
        }
        
        var error: ValidationError?
        
        if !failed.isEmpty || !big.isEmpty {
            
            var messages = [String]()
            
            if !failed.isEmpty {
                messages.append(String(format: "Unable to open: %@", failed.map({ $0.lastPathComponent }).joined(separator: ", ")))
            }
            
            if !big.isEmpty {
                let files = big.map({ String(format: "%@ (%.2fMb)", $0.0.lastPathComponent, $0.1) })
                messages.append(String(format: "Bigger than %dMb: %@", size, files.joined(separator: ", ")))
            }
            
            error = ValidationError(message: messages.joined(separator: ". "))
        }
        
        return (urls, error)
    }
    
    private func size(for url: URL) -> UInt64? {
        
        do {
            
            let attr = try FileManager.default.attributesOfItem(atPath: url.path)
            guard var fileSize = attr[FileAttributeKey.size] as? UInt64 else {
                return nil
            }
            
            let dict = attr as NSDictionary
            fileSize = dict.fileSize()
            
            return fileSize
        } catch {
            return nil
        }
    }
}
