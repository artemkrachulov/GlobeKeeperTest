//
//  ValidatorType.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation

enum ValidatorType {
    case size(Int)
    case count(Int)
}
