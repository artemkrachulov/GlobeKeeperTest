//
//  VaildatorFactory.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation

enum VaildatorFactory {
    
    static func validatorFor(type: ValidatorType) -> Validated {
        switch type {
        case .size(let maxMb): return FileSizeValidator(maxMb)
        case .count(let max): return FileCountValidator(max)
        }
    }
}
