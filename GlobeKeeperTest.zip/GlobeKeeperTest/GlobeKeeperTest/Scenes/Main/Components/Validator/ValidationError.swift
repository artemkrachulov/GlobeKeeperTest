//
//  ValidationError.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation

public struct ValidationError: LocalizedError {
    
    // MARK: -
    // MARK: ** Properties **
    
    public let message: String
    public var errorDescription: String? { return message }
    
    // MARK: -
    // MARK: ** Initialization **
    
    public init(message: String) {
        self.message = message
    }
}
