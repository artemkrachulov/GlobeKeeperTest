//
//  Validated.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation

protocol Validated {
    
    func validated(_ urls: [URL]) -> ([URL], ValidationError?)
}
