//
//  Array+validate.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import Foundation

extension Array where Element == URL {

    mutating func validate(validationType: ValidatorType) -> ValidationError? {
        let validator = VaildatorFactory.validatorFor(type: validationType)
        
        let (urls, error) = validator.validated(self)
        self = urls
        return error
    }
}
