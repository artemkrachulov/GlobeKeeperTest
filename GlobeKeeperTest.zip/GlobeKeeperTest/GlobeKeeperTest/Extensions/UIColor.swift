//
//  UIColor.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

extension UIColor {
   
    // #1D2733
    open class var mirage: UIColor {
        return UIColor(red: 29/255, green: 39/255, blue: 51/255, alpha: 1.0)
    }
    
    // #E7E7E7
    open class var mercury: UIColor {
        return UIColor(red: 231/255, green: 231/255, blue: 231/255, alpha: 1.0)
    }
    
    // #DCDBE3
    open class var mischka: UIColor {
        return UIColor(red: 220/255, green: 219/255, blue: 227/255, alpha: 1.0)
    }
    
    // #66C3C8
    open class var downy: UIColor {
        return UIColor(red: 102/255, green: 195/255, blue: 200/255, alpha: 1.0)
    }
    
    // #FB566B
    open class var carnation: UIColor {
        return UIColor(red: 251/255, green: 86/255, blue: 107/255, alpha: 1.0)
    }
}
