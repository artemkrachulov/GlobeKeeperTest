//
//  API.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit
import Moya

enum API: TargetType {
    
    case upload(URL)
    
    var baseURL: URL {
        return URL(string: "https://api.stg.globekeeper.com/")!
    }
    
    var path: String {
        return "testUpload"
        
    }
    
    var method: Moya.Method {
        return .post
    }
    
    var task: Task {
        switch self {
        case .upload(let url):
            
            var multipartData = [MultipartFormData]()
            let fileName: String = url.lastPathComponent
            do {
                
                let data = try Data(contentsOf: url)
                
                multipartData.append(MultipartFormData(provider: .data(data), name: "upload", fileName: fileName, mimeType: data.mimeType))
            } catch {}
            
            do {
                let parameters: [String: Any] = ["name": fileName]
                let json = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
                
                multipartData.append(MultipartFormData(provider: .data(json), name: "data"))
            } catch {}
            
            return .uploadMultipart(multipartData)
        }
    }
    
    var sampleData: Data {
        return Data()
    }
    
    var headers: [String: String]? {
        return ["Content-Type": "multipart/form-data" ]
    }
    
    var validationType: ValidationType {
        return ValidationType.none
    }
}
