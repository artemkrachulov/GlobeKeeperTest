//
//  ImageFactory.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

final class ImageFactory {
    
    static func makeImageFrom(ext: String) -> UIImage? {
        switch ext {
        case "jpg", "jpeg":
            return UIImage(named: "image")
        case "rtf", "docx":
            return UIImage(named: "doc")
        case "pdf":
            return UIImage(named: "pdf")
        default:
            return nil
        }
    }
    
    static func makeImage(for state: UploadItemState) -> UIImage? {
        switch state {
        case .ok:
            return UIImage(named: "ok")
        case .fail:
            return UIImage(named: "fail")
        case .uploading:
            return UIImage(named: "stop")
        }
    }
}
