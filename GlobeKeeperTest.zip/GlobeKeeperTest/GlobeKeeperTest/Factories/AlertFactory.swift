//
//  AlertFactory.swift
//  GlobeKeeperTest
//
//  Created by Artem on 15.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

final class AlertFactory {
    
    static func makeValidation(errors: [String], continueHandler: @escaping () -> Void) -> UIAlertController {
        
        let message = String(format: "Found follow validation errors:\n\n %@ \n\nThese fiel(s) will be skipped.", errors.joined(separator: "\n"))
        
        let alert = UIAlertController(title: "Warning!", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Continue", style: .default, handler: { _ in continueHandler() }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .destructive))
        
        return alert
    }
}
