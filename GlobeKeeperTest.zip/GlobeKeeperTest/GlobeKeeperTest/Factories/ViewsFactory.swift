//
//  ViewsFactory.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

import UIKit

final class ViewsFactory {
    
    static func makeStackView() -> UIStackView {

        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 0

        return stackView
    }    
}
