//
//  Value.swift
//  GlobeKeeperTest
//
//  Created by Artem on 14.02.2020.
//  Copyright © 2020 Artem Krachulov. All rights reserved.
//

class Value<T: Equatable> {
    
    private let oldValue: T
    
    init(_ value: T) {
        self.oldValue = value
        self.value = value
    }
    
    var value: T {
        didSet {
            isChangedInitial = self.oldValue != value
            
            guard oldValue != value else { return }
            isChanged = oldValue != value
        }
    }

    var isChangedInitial: Bool = false {
        didSet {
            guard oldValue != isChangedInitial else { return }
            didChangeInitial?(isChangedInitial, value)
        }
    }
        
    var didChangeInitial: ((Bool, T) -> Void)? {
        didSet { didChangeInitial?(isChangedInitial, value) }
    }
    
    var isChanged: Bool = false {
        didSet { didChange?(isChanged, value) }
    }
    
    var didChange: ((Bool, T) -> Void)? {
        didSet { didChange?(isChanged, value) }
    }
}
